const at = document.querySelectorAll('.nav-link')[3]
const hidden = document.querySelector('.hidden')
const opt = document.querySelector('.opt-1')

const home = document.getElementById('home')

at.addEventListener("click", function (e) {
    e.preventDefault()

    if (hidden.style.display === "none") {
        hidden.style.display = "block";
    }
    else {
        hidden.style.display = "none";
    }
})

home.addEventListener("click", function (e) {
    e.preventDefault()

    if (hidden.style.display === "block") {
        hidden.style.display = "none";
    }
})